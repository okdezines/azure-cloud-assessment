TASK 3 EVIDENCE PACKAGE

Copy the images/ folder into your Next.js public/ folder.
Use URL paths beginning /images/task-3/evidence/ (omit public).
Figures 3.2 and 3.3 are B1 and B2; subsequent figures are grouped by checkpoint.
Existing files have been renamed without editing their pixels. The index maps old to new names.
Screenshots demonstrate only what is visible; do not interpret filenames as proof of successful testing.

OPTIONAL PLACEHOLDERS (not created as fake images):
- B3: Firewall overview confirming current private IP 10.0.0.132 and attached policy, if not legible in existing overview
- B4: Policy rule priority/source/FQDN/protocol details, if not legible in existing captures
- B6: Dated side-by-side allowed and blocked website tests from the assessed VM, if needed
- B6: Firewall logs correlated to the same test time and VM, if needed
